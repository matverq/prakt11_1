﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prakt11_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student stud = new Student((double)numericUpDown1.Value);
            stud.name = textBox1.Text;
            stud.rost = (double)numericUpDown2.Value;
            stud.sStudent((double)numericUpDown1.Value);
            stud.food = (double)numericUpDown3.Value;
            stud.SetEat(stud.food);
            MessageBox.Show(string.Format($"Студент с кг еды - {stud.food}: {stud.name} \nрост: {stud.rost} \nвес: { stud.GetEat()}"));
            
        }
    }
}
